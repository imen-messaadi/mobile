package com.example.transtu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;

public class ModifierMotDePasseActivity extends AppCompatActivity {

    TextInputLayout textInputAncien, textInputNouveau, textInputConfirmer;
    Button buttonRetour, buttonValider;

    String ancien, nouveau, confirmer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifier_mot_de_passe);

        textInputAncien = findViewById(R.id.text_input_ancien);
        textInputNouveau = findViewById(R.id.text_input_nouveau);
        textInputConfirmer = findViewById(R.id.text_input_confirmer);
        buttonRetour = findViewById(R.id.button_retour);
        buttonValider = findViewById(R.id.button_valider);

        buttonRetour.setOnClickListener(v -> {
            onBackPressed();
        });

        buttonValider.setOnClickListener(v -> {

            ancien = textInputAncien.getEditText().getText().toString();
            nouveau = textInputNouveau.getEditText().getText().toString();
            confirmer = textInputConfirmer.getEditText().getText().toString();

            if (validateForm(ancien, nouveau, confirmer)) {
                onBackPressed();
            }

        });
    }

    private boolean validateForm(String ancien, String nouveau, String confirmer) {
        textInputAncien.setError(null);
        textInputNouveau.setError(null);
        textInputConfirmer.setError(null);

        if (ancien.isEmpty()) {
            textInputAncien.setError("entrer votre ancien mot de passe.");
            return false;
        } else if (nouveau.isEmpty()) {
            textInputNouveau.setError("entrer nouveau mot de passe.");
            return false;
        } else if (confirmer.isEmpty()) {
            textInputConfirmer.setError("confirmer nouveau mot de passe.");
            return false;
        } else if (ancien.length() < 8) {
            textInputAncien.setError("Mot de passe doit être d'au moins 8 caractères.");
            return false;
        } else if (nouveau.length() < 8) {
            textInputNouveau.setError("Mot de passe doit être d'au moins 8 caractères.");
            return false;
        } else if (confirmer.length() < 8) {
            textInputConfirmer.setError("Mot de passe doit être d'au moins 8 caractères.");
            return false;
        } else if (!nouveau.equals(confirmer)) {
            textInputNouveau.setError("Mot de passe non identique.");
            textInputConfirmer.setError("Mot de passe non identique.");
            return false;
        }

        return true;
    }
}