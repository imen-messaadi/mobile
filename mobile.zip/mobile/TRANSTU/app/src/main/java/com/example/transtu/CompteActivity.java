package com.example.transtu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.getbase.floatingactionbutton.FloatingActionButton;

public class CompteActivity extends AppCompatActivity {

    FloatingActionButton fabModifierProfil, fabModifierMDP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compte);

        fabModifierProfil = findViewById(R.id.fab_modifier_profil);
        fabModifierMDP = findViewById(R.id.fab_modifier_mdp);

        fabModifierProfil.setOnClickListener(v -> {
            startActivity(new Intent(CompteActivity.this, ModifierProfilActivity.class));
        });

        fabModifierMDP.setOnClickListener(v -> {
            startActivity(new Intent(CompteActivity.this, ModifierMotDePasseActivity.class));
        });
    }
}