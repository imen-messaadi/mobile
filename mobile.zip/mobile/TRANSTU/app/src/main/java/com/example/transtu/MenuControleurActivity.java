package com.example.transtu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;

public class MenuControleurActivity extends AppCompatActivity {

    CardView cardViewScanQR, cardViewHistorique, cardViewCompte, cardViewDeconnexion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_controleur);

        getSupportActionBar().hide();

        cardViewScanQR = findViewById(R.id.card_view_scan_qr);
        cardViewHistorique = findViewById(R.id.card_view_historique);
        cardViewCompte = findViewById(R.id.card_view_compte);
        cardViewDeconnexion = findViewById(R.id.card_view_deconnexion);

        cardViewScanQR.setOnClickListener(v -> {
            startActivity(new Intent(MenuControleurActivity.this, ScanQRActivity.class));
        });

        cardViewHistorique.setOnClickListener(v -> {
            startActivity(new Intent(MenuControleurActivity.this, HistoriqueActivity.class));
        });

        cardViewCompte.setOnClickListener(v -> {
            startActivity(new Intent(MenuControleurActivity.this, CompteActivity.class));
        });

        cardViewDeconnexion.setOnClickListener(v -> {
            startActivity(new Intent(MenuControleurActivity.this, AuthentificationActivity.class));
            finish();
        });
    }
}