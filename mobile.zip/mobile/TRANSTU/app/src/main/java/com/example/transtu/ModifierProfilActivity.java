package com.example.transtu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;

import com.example.transtu.models.Utilisateur;
import com.google.android.material.textfield.TextInputLayout;

public class ModifierProfilActivity extends AppCompatActivity {

    TextInputLayout textInputCIN, textInputNom, textInputPrenom, textInputNumTel, textInputAdresse, textInputVille;
    AutoCompleteTextView autoCompleteVille;
    Button buttonRetour, buttonValider;

    ArrayAdapter<String> villeAdapter;
    String[] VILLES = {
            "Tunis", "Ariana", "Ben Arous", "Manouba", "Nabeul", "Zaghouan", "Bizerte", "Beja", "Jendouba", "Kef", "Siliana", "Sousse",
            "Monastir", "Mahdia", "Sfax", "Kairouan", "Kasserine", "Sidi Bouzid", "Gabes", "Medenine", "Tataouine", "Gafsa", "Tozeur", "Kebili"
    };

    Utilisateur utilisateur;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifier_profil);

        textInputCIN = findViewById(R.id.text_input_cin);
        textInputNom = findViewById(R.id.text_input_nom);
        textInputPrenom = findViewById(R.id.text_input_prenom);
        textInputNumTel = findViewById(R.id.text_input_num_tel);
        textInputAdresse = findViewById(R.id.text_input_adresse);
        textInputVille = findViewById(R.id.text_input_ville);
        autoCompleteVille = findViewById(R.id.auto_complete_ville);
        buttonRetour = findViewById(R.id.button_retour);
        buttonValider = findViewById(R.id.button_valider);

        villeAdapter = new ArrayAdapter<String>(ModifierProfilActivity.this, android.R.layout.simple_list_item_1, VILLES);
        autoCompleteVille.setAdapter(villeAdapter);

        buttonRetour.setOnClickListener(v -> {
            onBackPressed();
        });

        buttonValider.setOnClickListener(v -> {

//            if (validateForm()) {
//                onBackPressed();
//            }

        });
    }
}