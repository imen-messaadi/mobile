package com.example.transtu.api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

// singleton
public class APIClient {

    private static Retrofit retrofit;

    public static Retrofit getRetrofit(){
        if(retrofit == null){
            // creation d'un instance du retrofit
            retrofit  = new Retrofit.Builder()
                    .baseUrl("http://192.168.13.112:5000/") // localhost !!!! adresse ip du pc : netstat
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

}
