package com.example.transtu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class SplashScrennActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screnn);

        // pour cacher actionbar
        getSupportActionBar().hide();

        // apres 3.5 sec, redirection vers AuthentificationActivity
        new Handler().postDelayed(() -> {

            Intent intent = new Intent(SplashScrennActivity.this, AuthentificationActivity.class);
            startActivity(intent);

        }, 3500);
    }
}