package com.example.transtu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.example.transtu.api.APIClient;
import com.example.transtu.api.APIInterface;
import com.example.transtu.api.APIResponse;
import com.example.transtu.models.Utilisateur;
import com.google.android.material.textfield.TextInputLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class AuthentificationActivity extends AppCompatActivity {

    // déclaration
    TextInputLayout textInputLogin, textInputMotDePasse;
    Button buttonSeConnecter;

    Utilisateur utilisateur;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentification);

        // liaison
        textInputLogin = findViewById(R.id.text_input_login);
        textInputMotDePasse = findViewById(R.id.text_input_mot_de_passe);
        buttonSeConnecter = findViewById(R.id.button_se_connecter);

        buttonSeConnecter.setOnClickListener(v -> {
            // action button se connecter

            // creation d'une instance du class: Utilisateur
            utilisateur = new Utilisateur();

            // récuperation du login et mot de passe
            utilisateur.setLogin(textInputLogin.getEditText().getText().toString());
            utilisateur.setMotDePasse(textInputMotDePasse.getEditText().getText().toString());

            // controle de saisie
            if (validateForm(utilisateur)) {
                // appel retrofit
                Retrofit client = APIClient.getRetrofit();
                // init interface
                APIInterface api = client.create(APIInterface.class);

                // appel function auth
                Call<APIResponse> call = api.auth(utilisateur);

                // callback: réponde eli bech trja3 chnawa bech n3ml beha
                call.enqueue(new Callback<APIResponse>() {
                    @Override
                    public void onResponse(Call<APIResponse> call, Response<APIResponse> response) {

                        // vérif: communication + cors du réponse
                        if (response.isSuccessful() && response.body() != null) {

                            APIResponse res = response.body();
                            if(res.isSuccess()){ // si true: login et mdp sont correctes

                                // test sur: Role
                                // si role == CONTROLEUR
                                    // redirection vers menu controleur
                                // si role == ABONNEE
                                    // redirection vers menu abonnee
                                // si role == ADMIN
                                    // non authorizé

                                if(res.getUtilisateur().getRole().equals("CONTROLEUR")){
                                    startActivity(new Intent(AuthentificationActivity.this, MenuControleurActivity.class));
                                }else  if(res.getUtilisateur().getRole().equals("ABONNEE")){
                                    startActivity(new Intent(AuthentificationActivity.this, MenuAbonneeActivity.class));
                                }else {
                                    Toast.makeText(
                                            AuthentificationActivity.this,
                                            "vous n'êtes pas autorisé à utiliser cette application",
                                            Toast.LENGTH_LONG).show();
                                }

                            }else{ // login et mdp se sont pas correctes
                                Toast.makeText(
                                        AuthentificationActivity.this,
                                        res.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            }

                        } else {
                            Toast.makeText(
                                    AuthentificationActivity.this,
                                    "Error",
                                    Toast.LENGTH_LONG).show();
                        }

                    }

                    @Override
                    public void onFailure(Call<APIResponse> call, Throwable t) {
                        // si error
                        Toast.makeText(
                                AuthentificationActivity.this,
                                "Error: " + t.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });

            }

        });

    }

    private boolean validateForm(Utilisateur utilisateur) {

        // vérif login
        // login: non vide
        // login: xxxxx@xxx.xxx || longeur: 4

        // vérif mot de passe
        // mdp: non vide
        // mdp: longeur . >=8

        return true;
    }


}